# README
Run `combustion.py` using Python 3.

Edit lines 7-13 to alter system configuration. Iterator takes much longer to converge for lower (sub-1000K) temperatures.

There is a list of species in `data.py`. Any of those species are good to put into 'composition'. 